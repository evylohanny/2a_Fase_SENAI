import Navbar from "../components/Navbar"

function Final() {
  return (
    <div>
        <Navbar />
      <h1>Final</h1>
      <p>Você chegou ao fim da internet, por enquanto...</p>
    </div>
  )
}

export default Final
