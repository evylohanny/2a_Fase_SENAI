import Navbar from "../components/Navbar"

function Contato() {
  return (
    <div>
        <Navbar />
      <h1>Contato</h1>
      <p>falecomagente falecomagente falecomagente falecomagente falecomagente falecomagente falecomagente falecomagente falecomagente </p>
    </div>
  )
}

export default Contato
