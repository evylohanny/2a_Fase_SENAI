import Navbar from "../components/Navbar"

function Generica() {
  return (
    <div>
        <Navbar />
      <h1>Genérica</h1>
      <p>Coisas genéricas, nada específicas...</p>
    </div>
  )
}

export default Generica
