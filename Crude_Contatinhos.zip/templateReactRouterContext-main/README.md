# Template para projeto React

Template para projeto React, contendo:
- Contexto global com useContext;
- Roteamento de páginas com react-router-dom

Ideal para usar como base para começar um projeto React depois do almoço.